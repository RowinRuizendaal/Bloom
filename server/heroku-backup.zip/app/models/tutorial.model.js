// module.exports = (mongoose) => {
//   const Tutorial = mongoose.model(
//     'tutorial',
//     mongoose.Schema(
//       {
//         firstName: String,
//         surName: String,
//         emailaddress: String,
//         birthdate: String,
//         town: String,
//         gender: String,
//         typeIllness: String,
//         profileAvatar: String,
//         about: String,
//       },
//       { timestamps: true }
//     )
//   );

//   return Tutorial;
// };
